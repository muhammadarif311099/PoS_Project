<?= $this->extend('layout/templates'); ?>

<?= $this->section('isi'); ?>
<div class="container">
    <h1>Hello World!</h1>
</div>
<?= $this->endSection(); ?>