<footer>
    <p>Copyright Arif Faishal 2020.</p>
</footer>