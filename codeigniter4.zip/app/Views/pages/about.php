<?= $this->extend('layout/templates'); ?>

<?= $this->section('isi'); ?>
<div class="container">
    <h2>About Me</h2>
    <p>
        Halo nama saya Arif, Saya adalah seorang mahasiswa, Saya berusia 20 tahun.
    </p>
</div>
<?= $this->endSection(); ?>